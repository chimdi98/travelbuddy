

const TravelDetailsPage = () => {
    return(
        <main>

        </main>
    )
}
export default TravelDetailsPage;